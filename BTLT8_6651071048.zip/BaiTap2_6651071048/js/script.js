// script.js - JavaScript thuần cho menu di động và form đặt bánh
document.addEventListener("DOMContentLoaded", function () {
  var btn = document.getElementById("menu-btn");
  var menu = document.getElementById("mobile-menu");

  // Mở/đóng menu di động khi bấm icon hamburger
  btn.addEventListener("click", function () {
    var isHidden = menu.classList.toggle("hidden");
    menu.classList.toggle("flex", !isHidden);
    menu.classList.toggle("is-open", !isHidden);
    btn.setAttribute("aria-expanded", String(!isHidden));
  });

  // Tự đóng menu khi chọn một liên kết
  menu.querySelectorAll("a").forEach(function (link) {
    link.addEventListener("click", function () {
      menu.classList.add("hidden");
      menu.classList.remove("flex", "is-open");
      btn.setAttribute("aria-expanded", "false");
    });
  });

  // Nếu phóng to lên màn hình md trở lên thì đóng menu di động
  window.addEventListener("resize", function () {
    if (window.innerWidth >= 768) {
      menu.classList.add("hidden");
      menu.classList.remove("flex", "is-open");
      btn.setAttribute("aria-expanded", "false");
    }
  });

  // Gửi form: hiện thông báo nhỏ, không tải lại trang
  var form = document.getElementById("order-form");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = "Cảm ơn bạn! Bếp Bánh sẽ liên hệ sớm nhất.";
    document.body.appendChild(toast);
    form.reset();
    setTimeout(function () { toast.remove(); }, 3000);
  });
});
