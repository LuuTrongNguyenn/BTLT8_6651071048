// app.js - Vue 3 (CDN): giỏ hàng động + tìm kiếm sản phẩm
// Vue được nhúng bằng <script> TRƯỚC file này nên có thể gọi Vue.createApp.

// Hàm phụ: vẽ ảnh sản phẩm bằng SVG và trả về data URI (dùng làm thuộc tính "anh").
// Khi có ảnh thật, chỉ cần thay bằng đường dẫn, ví dụ "../images/op-lung-xanh.jpg".
function veAnh(loai, mau, mau2) {
  var than = "";
  if (loai === "case") {
    // Ốp lưng điện thoại
    than = '<rect x="95" y="38" width="110" height="224" rx="24" fill="' + mau + '"/>' +
      '<rect x="105" y="48" width="90" height="204" rx="17" fill="' + mau2 + '" opacity=".4"/>' +
      '<rect x="108" y="56" width="46" height="48" rx="13" fill="#111827"/>' +
      '<circle cx="123" cy="71" r="9" fill="#374151"/><circle cx="123" cy="71" r="4" fill="#9ca3af"/>' +
      '<circle cx="139" cy="90" r="9" fill="#374151"/><circle cx="139" cy="90" r="4" fill="#9ca3af"/>' +
      '<circle cx="150" cy="170" r="16" fill="#ffffff" opacity=".35"/>';
  } else if (loai === "charger") {
    // Đế sạc không dây
    than = '<ellipse cx="150" cy="198" rx="100" ry="30" fill="#000" opacity=".12"/>' +
      '<ellipse cx="150" cy="178" rx="100" ry="34" fill="' + mau + '"/>' +
      '<ellipse cx="150" cy="172" rx="76" ry="23" fill="' + mau2 + '"/>' +
      '<ellipse cx="150" cy="172" rx="28" ry="8" fill="#ffffff" opacity=".6"/>' +
      '<path d="M248 182 Q282 182 282 226" stroke="' + mau + '" stroke-width="7" fill="none" stroke-linecap="round"/>';
  } else if (loai === "earbuds") {
    // Hộp sạc + 2 tai nghe
    than = '<ellipse cx="150" cy="232" rx="82" ry="14" fill="#000" opacity=".12"/>' +
      '<rect x="88" y="130" width="124" height="98" rx="44" fill="' + mau + '"/>' +
      '<path d="M88 168 H212" stroke="' + mau2 + '" stroke-width="3"/>' +
      '<circle cx="150" cy="196" r="5" fill="#22c55e"/>' +
      '<ellipse cx="112" cy="84" rx="17" ry="23" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>' +
      '<rect x="120" y="92" width="9" height="42" rx="4" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>' +
      '<ellipse cx="188" cy="84" rx="17" ry="23" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>' +
      '<rect x="171" y="92" width="9" height="42" rx="4" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>';
  } else {
    // Cáp sạc bện dù
    than = '<path d="M60 220 C95 70 135 270 175 125 S240 95 250 72" stroke="' + mau + '" stroke-width="11" fill="none" stroke-linecap="round"/>' +
      '<path d="M60 220 C95 70 135 270 175 125 S240 95 250 72" stroke="' + mau2 + '" stroke-width="3" fill="none" stroke-dasharray="6 8" stroke-linecap="round"/>' +
      '<rect x="40" y="218" width="30" height="46" rx="8" fill="#9ca3af"/><rect x="48" y="264" width="14" height="14" fill="#6b7280"/>' +
      '<rect x="236" y="30" width="30" height="46" rx="8" fill="#9ca3af"/><rect x="244" y="18" width="14" height="14" fill="#6b7280"/>';
  }
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="300" height="300">' +
    '<rect width="300" height="300" fill="#eef2f7"/>' + than + '</svg>';
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}

Vue.createApp({
  // ===== DỮ LIỆU (reactive data) =====
  data() {
    return {
      tuKhoa: "",   // từ khoá tìm kiếm, liên kết 2 chiều với ô input bằng v-model
      cart: [],     // mảng giỏ hàng: thay đổi mảng này là giao diện tự cập nhật
      products: [   // danh sách sản phẩm (8 phụ kiện)
        { id: 1, ten: "Ốp lưng Electric Blue", gia: 250000, moTa: "Ốp chống sốc, viền xanh điện", anh: veAnh("case", "#2563eb", "#93c5fd") },
        { id: 2, ten: "Ốp lưng Clear Crystal", gia: 180000, moTa: "Trong suốt, chống ố vàng", anh: veAnh("case", "#d1d5db", "#ffffff") },
        { id: 3, ten: "Sạc không dây Pad 15W", gia: 250000, moTa: "Sạc nhanh, chuẩn Qi", anh: veAnh("charger", "#1f2937", "#4b5563") },
        { id: 4, ten: "Tai nghe Active TWS", gia: 350000, moTa: "Chống ồn, pin 24 giờ", anh: veAnh("earbuds", "#f8fafc", "#cbd5e1") },
        { id: 5, ten: "Ốp lưng Matte Black", gia: 220000, moTa: "Nhám đen, chống bám vân tay", anh: veAnh("case", "#111827", "#6b7280") },
        { id: 6, ten: "Sạc không dây Mini", gia: 199000, moTa: "Nhỏ gọn, mang đi du lịch", anh: veAnh("charger", "#e5e7eb", "#9ca3af") },
        { id: 7, ten: "Tai nghe TWS Pro", gia: 450000, moTa: "Âm thanh Hi-Fi, kháng nước", anh: veAnh("earbuds", "#1f2937", "#374151") },
        { id: 8, ten: "Cáp USB-C bện dù", gia: 120000, moTa: "Dài 1.5m, sạc nhanh 60W", anh: veAnh("cable", "#2563eb", "#1e40af") }
      ]
    };
  },

  // ===== COMPUTED: giá trị tự tính lại khi dữ liệu nguồn thay đổi =====
  computed: {
    // Số sản phẩm trong giỏ, hiển thị ở header: Giỏ hàng ({{ cartCount }})
    cartCount() {
      return this.cart.length;
    },
    // Tổng tiền: cộng giá của mọi sản phẩm trong cart; cart đổi là tự tính lại
    tongTien() {
      return this.cart.reduce(function (tong, sp) { return tong + sp.gia; }, 0);
    },
    // Lọc sản phẩm theo từ khoá (không phân biệt hoa thường).
    // Giao diện render danhSachLoc thay vì toàn bộ products => "UI = function của data".
    danhSachLoc() {
      var kw = this.tuKhoa.trim().toLowerCase();
      return this.products.filter(function (sp) {
        return sp.ten.toLowerCase().includes(kw) || sp.moTa.toLowerCase().includes(kw);
      });
    }
  },

  // ===== METHODS: các hành động do người dùng kích hoạt =====
  methods: {
    // Thêm sản phẩm vào giỏ: chỉ push vào mảng cart.
    // So sánh với Vanilla JS: nếu dùng Vanilla JS, mỗi lần thêm/xoá giỏ hàng phải tự
    // querySelector + cập nhật DOM thủ công (số lượng ở header, danh sách và tổng tiền ở aside).
    // Vue tự động làm điều này nhờ reactivity.
    themVaoGio(sanPham) {
      this.cart.push(Object.assign({}, sanPham)); // copy để mỗi lần thêm là một dòng riêng
    },
    // Xoá sản phẩm khỏi giỏ theo vị trí (index) trong mảng cart
    xoaKhoiGio(index) {
      this.cart.splice(index, 1);
    },
    // Định dạng giá tiền kiểu Việt Nam, ví dụ 250000 -> "250.000 VND"
    dinhDangGia(gia) {
      return gia.toLocaleString("vi-VN") + " VND";
    }
  }
}).mount("#app");
